package mpp_labs.lesson3.prob4;

public interface Property {
	
	double computeRent();

}
