package mpp_labs.lesson3.prob4;

public class Trailer implements Property{

	private double rent;
	public Trailer() {
		// TODO Auto-generated constructor stub
	
	}
	
	public double computeRent() {
		// TODO Auto-generated method stub
		return 500;
	}

}
