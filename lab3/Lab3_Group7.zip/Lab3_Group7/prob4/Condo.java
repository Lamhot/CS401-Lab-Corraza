package mpp_labs.lesson3.prob4;

public class Condo implements Property{

	private double rent;
	private int numsOfFloor;
	public Condo(int floor) {
		// TODO Auto-generated constructor stub
		this.numsOfFloor= floor;
	}

	public double computeRent() {
		// TODO Auto-generated method stub
		return 400*this.numsOfFloor;
	}

}
