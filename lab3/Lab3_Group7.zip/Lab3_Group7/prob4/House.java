package mpp_labs.lesson3.prob4;

public class House implements Property{

	private int size;
	public House(int size) {
		// TODO Auto-generated constructor stub
		this.size= size;
	}

	public double computeRent() {
		// TODO Auto-generated method stub
		double rent =0.0;
		rent = 0.1 * size;
		return rent;
	}

}
