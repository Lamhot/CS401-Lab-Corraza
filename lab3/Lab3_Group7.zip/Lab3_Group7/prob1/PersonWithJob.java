package mpp_labs.lesson3.prob1;

public class PersonWithJob{
	
	private double salary;
	Person value;
	
	public double getSalary() {
		return salary;
	}
	PersonWithJob(String n, double s) {
		this.value= new Person(n);
		salary = s;
	}
	
	@Override
	public boolean equals(Object aPerson) {
		if(aPerson == null) return false; 
		if(!(aPerson instanceof PersonWithJob)) return false;
		PersonWithJob p = (PersonWithJob)aPerson;
		boolean isEqual = this.value.getName().equals(p.value.getName()) &&
				this.getSalary()==p.getSalary();
		return isEqual;
	}
	
}
