package mpp_labs.lesson3.prob2;

import java.util.List;

public class Building {
	private List<Apartment> apartments;
	int maintenaceCost;

	public Building(int cost, List<Apartment> apts) {
		this.maintenaceCost = cost;
		this.apartments = apts;
	}

	public Integer getProfit() {
		int profit = 0;
		for (Apartment apt : apartments) {
			profit += apt.getRent();
		}
		return profit - this.maintenaceCost;
	}

}
