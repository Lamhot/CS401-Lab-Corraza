package mpp_labs.lesson3.prob2;

import java.util.ArrayList;
import java.util.List;

public class LandlordInfo {
	
  List<Building> buildings = new ArrayList<Building>();
	
	public void Landlord(List<Building> bs) {
		this.buildings= bs;
	}
	
	public int calcProfits() {
		int total = 0;
		for (Building b: buildings) {
			total += b.getProfit();
		}
		return total;
	}
	public void addBuilding(Building b) {
		// TODO Auto-generated method stub
		buildings.add(b);
		
	}

}
