package mpp_labs.lesson3.prob2;


public class Apartment {

	private int rent;

	public Apartment(int rent) {
		this.rent = rent;
	}

	public Integer getRent() {
		return rent;
	}

}
