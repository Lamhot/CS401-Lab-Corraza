package mpp_labs.lesson3.prob3.inheritance;

public class Circle {
	private double radius;


	public Circle(double radius) {
		this.radius = radius;

	}

	public double getRadius() {
		return this.radius;
	}

	public double getArea() {
		return this.radius * this.radius * Math.PI;
	}

	@Override
	public String toString() {
		return "Area of circle = " + getArea();
	}

}