package mpp_labs.lesson3.prob3.inheritance;

public class Main {
	public static void main(String[] args) {

		Cylinder cylinder_ob = new Cylinder(6,12);

		System.out.println(cylinder_ob);
	}
}