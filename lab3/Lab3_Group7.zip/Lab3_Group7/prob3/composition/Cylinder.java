package mpp_labs.lesson3.prob3.composition;

public class Cylinder{
	Circle circle;
	private double height;
	
	
	public Cylinder(double radius, double height){
		circle = new Circle(radius);
		this.height = height;
	}

	public double getHeight() {
		return this.height;
	}

	public double getVolume(){
		return this.height* this.circle.getArea();
	}
	
	@Override
	public String toString() {
		return "Volume: " + getVolume();
	}
}