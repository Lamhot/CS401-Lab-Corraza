package lesson10.labs.prob4;

public enum Status {
	GOLD, SILVER, COMMON, ILLEGAL
}
