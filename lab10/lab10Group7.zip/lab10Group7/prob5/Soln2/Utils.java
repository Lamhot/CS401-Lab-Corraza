package lab10.prob5.Soln2;

import java.util.List;
import java.util.stream.Collectors;

import lab10.prob5.Employee;

public class Utils {
	public static String helperConverter(List<Employee> list) {
        return list.stream()
	    .filter(LibraryUtils::salaryGreaterThan100000)
	    .filter(LibraryUtils::lastNameAfterM)
	    .map(LibraryUtils::fullName)
	    .sorted()
	    .collect(Collectors.joining(", ")).toString();
	}
}