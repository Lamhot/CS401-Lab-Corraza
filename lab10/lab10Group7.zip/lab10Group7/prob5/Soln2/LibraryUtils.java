package lab10.prob5.Soln2;

import lab10.prob5.Employee;

public class LibraryUtils {
	public static boolean salaryGreaterThan100000(Employee e){
		return e.getSalary() > 100000 ? true : false;
	}
	
	public static boolean lastNameAfterM(Employee e) {
		return e.getLastName().charAt(0) > 'M' ? true : false;
	}
	
	public static String fullName(Employee e) {
		return e.getFirstName() + " " + e.getLastName();
	}
}