package lab10.prob6;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class QueueThreadsafeTest {

	static QueueThreadSafe q = new QueueThreadSafe();
	static List<Thread> list = new ArrayList<Thread>();
	public static void main(String[] args) {

		for(int i = 0; i < 10; ++i) {
			list.clear();
			multipleCalls();
			try  
	        {  
	            for (Thread my : list)  
	            {  
	                my.join();  
	            }  
	        }  
	        catch (InterruptedException e)  
	        {  
	            e.printStackTrace();  
	        } 
			System.out.println(q.getCount());
		}	
	}
	
	public static void multipleCalls() {
		Runnable r = () -> {
			for(int i = 0; i < 50; ++i) {
				q.add("888");
				
				try {
					TimeUnit.MILLISECONDS.sleep(1);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				
				q.remove();
			}
		};
		
		for(int i = 0; i < 5; ++i) {
			Thread t = new Thread(r);
			list.add(t);
			t.start();
			
		}

	}

}