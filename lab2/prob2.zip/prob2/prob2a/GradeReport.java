package mpp_labs.lesson2.prob2a;

public class GradeReport {
	private Student objStudent;
	private double gpa;

	GradeReport(Student student, double gpa) {
		objStudent = student;
		this.gpa= gpa;
	}
	
	public Student getGradeReport() {
		return objStudent;
	}

	public double getGpa() {
		return gpa;
	}

	public void setGpa(double gpa) {
		this.gpa = gpa;
	}
	
	
	
	
	


	
	
}
