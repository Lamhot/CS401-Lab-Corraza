package mpp_labs.lesson2.prob2a;

public class Student {
	private String name;
	
	private GradeReport grades;
	public Student(String name, double gpa ) {
		this.name = name;
		 grades = new GradeReport(this, gpa);		
	}
	public String getName() {
		return name;
	}
	public GradeReport getGradeReport() {
		return grades;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", grades="  +  grades.getGpa() +"]";
	}
	
	
}
