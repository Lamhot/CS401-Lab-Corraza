package mpp_labs.lesson2.prob2a;


public class Main {

	public static void main(String[] args) {
		Student studs = new Student("Bob", 4.0);
		GradeReport grade = studs.getGradeReport();
		System.out.println("Grade of student: " + grade.getGradeReport());

	}

}
