package ClassCodes.lecture2.bidir.onetomany;

public class Orderline {
	private int orderlineid;
	private String itemname;
	private Order custorder;
	
	Orderline (int id, String name, Order order)
	{
		this.orderlineid = id;
		this.itemname = name;
		this.custorder = order;
	}
	

	public int getOrderlineid() {
		return orderlineid;
	}

	public String getItemname() {
		return itemname;
	}
	
	
}
