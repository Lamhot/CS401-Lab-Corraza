package ClassCodes.lecture2.bidir.onetomany;

public class Main2 {

		public static void main(String args []) {
			Order thanksgiving = new Order (1, "Daniel Swanson", "Chicken Laps", 10);
			thanksgiving.addorderln(11, "Chicken Wings");
			thanksgiving.addorderln(12, "Seasoning");
			System.out.println(thanksgiving.toString());
		}
}
