package ClassCodes.lecture2.bidir.onetomany;

import java.util.ArrayList;
import java.util.List;

public class Order {
	private int orderid;
	private String customer;
	private List <Orderline> orderln = new ArrayList<>();
	
	Order (int id, String customer, String itemname, int orderlnid)
	{
		this.orderid = id;
		this.customer = customer;
		Orderline firstitem = new Orderline(orderlnid, itemname, this);
		orderln.add(firstitem);
		
	}
	
	public void addorderln(Order this, int orderlnid, String itemname)
		{
			Orderline newitem = new Orderline(orderlnid, itemname, this);
			orderln.add(newitem);
		}

	public int getId() {
		return orderid;
	}

	public String getCustomer() {
		return customer;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder("");
		for (int i=0; i<orderln.size(); ++i)
		{
			sb.append("[");
			sb.append(this.getId());
			sb.append("\t");
			sb.append(this.customer);
			sb.append("\t");
			sb.append(orderln.get(i).getOrderlineid());
			sb.append("\t");
			sb.append(orderln.get(i).getItemname());
			sb.append("]");
			sb.append("\n");
			
		}
		return sb.toString();
		
	}
	
	

}
