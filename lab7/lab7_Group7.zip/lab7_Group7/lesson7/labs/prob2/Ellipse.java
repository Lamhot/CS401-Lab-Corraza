package lesson7.labs.prob2;

public class Ellipse implements ClosedCurve {

	private double axis;
	private double elliptic;
	
	public Ellipse(int i, int j) {
		// TODO Auto-generated constructor stub
		this.axis = i;
		this.elliptic = j;
	}

	@Override
	public double computePerimeter() {
		// TODO Auto-generated method stub
		return 4 * axis * elliptic;
	}

}
