package lesson7.labs.prob2;

public class EquilateralTriangle implements Polygon {
	private double sideLength;


	public EquilateralTriangle(double i) {
		// TODO Auto-generated method stub
		this.sideLength = i;
	}
	
	@Override
	public double[] getSides() {
		// TODO Auto-generated method stub
		return new double[] { sideLength, sideLength, sideLength };
	}

	
	

}
