package lesson7.labs.prob1.partE.ii;

interface A {
    default void m() { System.out.println("hello from A"); }
}
