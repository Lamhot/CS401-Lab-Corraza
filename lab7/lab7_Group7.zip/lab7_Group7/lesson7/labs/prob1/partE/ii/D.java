package lesson7.labs.prob1.partE.ii;

class D implements B, C {}