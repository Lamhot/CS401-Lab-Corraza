package lesson7.labs.prob1.partE.ii;

interface C extends A {}