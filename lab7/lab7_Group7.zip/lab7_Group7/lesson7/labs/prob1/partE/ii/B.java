package lesson7.labs.prob1.partE.ii;

interface B extends A {
    default void m() { System.out.println("hello from B"); }
}
