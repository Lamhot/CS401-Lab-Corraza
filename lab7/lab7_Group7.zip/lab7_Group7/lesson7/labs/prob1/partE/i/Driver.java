package lesson7.labs.prob1.partE.i;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		D param = new D();
	    param.method();

	}

}
