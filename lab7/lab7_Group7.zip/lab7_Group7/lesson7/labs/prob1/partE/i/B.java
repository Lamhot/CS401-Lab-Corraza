package lesson7.labs.prob1.partE.i;

public interface B {
	public default void method() {
		System.out.println("B");
		
	}
}
