package lesson7.labs.prob1.partE.i;

public class D implements C,B,A {

	@Override
	public void method() {
		// TODO Auto-generated method stub
		B.super.method();
	}

	
	
	//public abstract void method();
	
}