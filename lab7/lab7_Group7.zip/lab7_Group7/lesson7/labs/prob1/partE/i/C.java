package lesson7.labs.prob1.partE.i;

public interface C {
	public default void method() {
		System.out.println("C");
	}
}