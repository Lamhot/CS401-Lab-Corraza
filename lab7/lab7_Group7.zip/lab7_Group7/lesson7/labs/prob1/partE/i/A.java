package lesson7.labs.prob1.partE.i;

public interface A {
	public abstract void method() ;
}
