package lesson7.labs.prob3;

import java.util.Arrays;
import java.util.List;

import java.util.function.Consumer;

public class ForEachExample {
	@SuppressWarnings("unused")
	List<String> list;

	public static void main(String[] args) {
		ForEachExample li = new ForEachExample();
		// print each element of the list in upper case format
		li.process();

	}

	public void process() {
		MyConsumer x = new MyConsumer();
		list = Arrays.asList("Hello there", "Goodbye", "Back soon", "Away", "On Vacation", "Everywhere you want to be");
		list.forEach(strList -> x.accept(strList));
		System.out.println(list);
	}

	public class MyConsumer implements Consumer<String> {

		@Override
		public void accept(String str) {
			System.out.println(str.toUpperCase());
		}
	}

}