package lesson7.labs.prob4;

public class RubberDuck extends Duck implements Squeakable, Flyable{
	
	@Override
	public void display() {
		System.out.println("  displaying");
		
	}

	@Override
	public void quack() {
		// TODO Auto-generated method stub
		super.quack();
	}
}
