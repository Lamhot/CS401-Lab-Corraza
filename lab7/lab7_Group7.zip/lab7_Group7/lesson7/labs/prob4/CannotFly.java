package lesson7.labs.prob4;

public class CannotFly implements Flyable {
	public void fly() {
		System.out.println("  cannot fly");
	}
}
