package lesson7.labs.prob4;

public class DecoyDuck extends Duck implements Unflyable, Unquackable {

	@Override
	public void display() {
		System.out.println("	displaying");

	}

	@Override
	public void fly() {
		Unflyable.super.fly();
	}

	@Override
	public void quack() {
		Unquackable.super.quack();
	}

}
