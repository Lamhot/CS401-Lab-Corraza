package lesson9.labs.prob4;

import java.math.BigInteger;
import java.util.stream.Stream;

public class PrimeStream {

	private void printFirstNPrimes(int i) {
		BigInteger big = new BigInteger("4");
		final Stream<BigInteger> primes = Stream.iterate(big, BigInteger::nextProbablePrime);//final
		primes.limit(i).forEach(System.out::println);

	}

	public static void main(String[] args) {

		PrimeStream ps = new PrimeStream();
		ps.printFirstNPrimes(10);
		System.out.println("------Result-----");
		ps.printFirstNPrimes(5);
	}
}
