package lesson9.labs.prob1.dataaccess;

import java.io.Serializable;

public enum Auth implements Serializable {
	LIBRARIAN, ADMIN, BOTH;
}
