package lesson10.labs.part2.prob10a;

public class Simple {
	boolean flag = false;
	Simple(boolean f) {
		flag = f;
	}
	@Override
	public String toString() {
		return "Simple [flag=" + flag + "]";
	}
}
