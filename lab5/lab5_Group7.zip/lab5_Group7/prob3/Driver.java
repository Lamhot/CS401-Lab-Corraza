package lesson5.labs.prob3;
import java.util.ArrayList;
import java.util.List;

public class Driver {
	static private List<ClosedCurve> listCloseCurve;
	
	public static void main(String[] args) {
		listCloseCurve = new ArrayList<ClosedCurve>();
		listCloseCurve.add(new Rectangle(15,14));
		listCloseCurve.add(new Circle(14));
		listCloseCurve.add(new Triangle(13, 15));
		double sum = 0.0;
		for(ClosedCurve cc:listCloseCurve) { // foreach loop
			sum += cc.computeArea();
		}
		System.out.println("Total sum:" + sum);
	}

}
