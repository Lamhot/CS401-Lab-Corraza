package lesson5.labs.prob3;

public interface ClosedCurve {
	
	public double computeArea();

}
