package lesson5.labs.prob4;

import java.time.LocalDate;


public class Driver {
	public static void main(String[] args) {
		Customer custumer = CustOrderFactory.createCustomer("Lamhot");
		Order order = CustOrderFactory.newOrder(custumer, LocalDate.now());
		order.addItem(CustOrderFactory.newItem("Kit Kat"));
		order.addItem(CustOrderFactory.newItem("Lays"));
		order.addItem(CustOrderFactory.newItem("Turkey"));

		order = CustOrderFactory.newOrder(custumer, LocalDate.now());
		order.addItem(CustOrderFactory.newItem("Cochalate"));
		order.addItem(CustOrderFactory.newItem("Mineral Water"));

		System.out.println(custumer.getOrders());
	}
}

		
