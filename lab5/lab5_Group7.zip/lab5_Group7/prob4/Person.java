package lesson5.labs.prob4;

public class Person {
	private String name;
	@Override
	public String toString() {
		return "Person [name=" + name + ", dob=" + dob + "]";
	}

	private BirthInfo dob;

	Person(String name) {
		this.name = name;
	}
}
