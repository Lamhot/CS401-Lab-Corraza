package lesson5.labs.prob4;

import java.time.LocalDate;

public class CustOrderFactory {
	public static Customer createCustomer(String name) {
		if(name == null) throw new NullPointerException("Customer name should be not null");
		return new Customer(name);
	}
	
	public static Order newOrder(Customer customer, LocalDate orderDate) {
		if(customer == null) throw new NullPointerException("there is no customerr");
		Order order = new Order(orderDate);
		customer.addOrder(order);
		return order;
		
	}
	public static void addOrder(Customer customer, Order order) {
		if(customer == null) throw new NullPointerException("there is no customer");
		customer.addOrder(order);
	}
	
	public static Item newItem(String name) {
		return new Item(name);
	}
	
	public static void addItem(Order order, Item item) {
		if(order == null) throw new NullPointerException("there is no customer");
		order.addItem(item);
	}
}
