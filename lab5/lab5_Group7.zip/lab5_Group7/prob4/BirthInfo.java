package lesson5.labs.prob4;

import java.time.LocalDate;

public class BirthInfo {
	private LocalDate dob;	
	BirthInfo(LocalDate dob) {
		this.dob = dob;
	}
	@Override
	public String toString() {
		return "BirthInfo [dob=" + dob + "]";
	}
	
}
