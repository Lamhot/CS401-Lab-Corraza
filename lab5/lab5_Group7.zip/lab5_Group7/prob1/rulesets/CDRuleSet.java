package lesson5.labs.prob1.rulesets;

import java.awt.Component;
import lesson5.labs.prob1.gui.*;

//import lesson5.labsolns.prob1.gui.CDWindow;

/**
 * Rules:
 *  1. All fields must be nonempty 
 *  2. Price must be a floating point number with two decimal places 
 *  3. Price must be a number greater than 0.49. 
 */

public class CDRuleSet implements RuleSet {
	private CDWindow CWindow;

	@Override
	public void applyRules(Component ob) throws RuleException {
		// TODO Auto-generated method stub
		CWindow= (CDWindow) ob;
		nonemptyRule();
		priceFloatRule();		
	}
	
	private void nonemptyRule() throws RuleException {
		if(CWindow.getArtistValue().trim().isEmpty() ||
				CWindow.getTitleValue().trim().isEmpty() ||
				CWindow.getPriceValue().trim().isEmpty())
				 
			throw new RuleException("All fields must be non-empty!");
		
	}
	
	private void priceFloatRule() throws RuleException {
		String val = CWindow.getPriceValue().trim();
		try {
			Float.parseFloat(val);
			//val is float
		} catch(NumberFormatException e) {
			throw new RuleException("Price must be float!");
		}
		
		
		int len =val.split(".").length;
		if(len!=2) throw new RuleException("Price must be a floating point number with two decimal places");
		
		float res= Float.parseFloat(val);
		if (res<0.49)
			throw new RuleException("Price must be a number greater than 0.49.");
		
	}
	
}
