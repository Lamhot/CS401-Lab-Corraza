package lesson5.labs.prob2;

public interface FlyBehavior {
	public void fly();
}
