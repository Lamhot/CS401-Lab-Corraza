package lesson6.labs.prob1;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class AddressForm extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Address Form");
        GridPane grid = new GridPane();
        
        grid.setGridLinesVisible(false) ;
        grid.setAlignment(Pos.CENTER);
        grid.setHgap(5);
        grid.setVgap(5);
        grid.setPadding(new Insets(25, 25, 25, 25));

        Label userNameLabel = new Label("Name");
        grid.add(userNameLabel, 0, 1);
        TextField nameTextField = new TextField();
        grid.add(nameTextField, 0, 2);

        Label streetLabel = new Label("Street");
        grid.add(streetLabel,1, 1);
        TextField streetTextField = new TextField();
        grid.add(streetTextField,1, 2);

        Label cityNameLabel = new Label("City");
        grid.add(cityNameLabel, 2, 1);
        TextField cityTextField = new TextField();
        grid.add(cityTextField, 2, 2);

        Label stateLabel = new Label("State");
        grid.add(stateLabel, 0, 3);
        TextField stateTextField = new TextField();
        grid.add(stateTextField, 0, 4);

        Label zipLabel = new Label("Zip");
        grid.add(zipLabel, 2, 4);
        TextField zipTextField = new TextField();
        grid.add(zipTextField, 2, 4);

        Button submitButton = new Button("Submit");
        HBox HButton = new HBox(10);
        HButton.setAlignment(Pos.BASELINE_CENTER);
        HButton.getChildren().add( submitButton);
        grid.add(HButton, 1, 5);
        submitButton.setOnAction(new EventHandler<ActionEvent>() {
        	@Override
        	public void handle(ActionEvent e) {
                System.out.println(nameTextField.getText().trim());
                System.out.println(streetTextField.getText().trim());
                System.out.println(cityTextField.getText().trim() + ", " + stateTextField.getText().trim()
                 + " " + zipTextField.getText().trim());
        	}
        });

        Scene scene = new Scene(grid);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}