package lab11.prob5;

import java.util.Arrays;
import java.util.List;

public class FindSecondSmallest {

	
		public static <T extends Comparable<T>> T secondSmallest(List<T> list)
		{
			T smallest  = list.get(0);
			T secondsmall  = list.get(0);
		
			for (T roll : list)
			{
				if (smallest.compareTo(roll) > 0)
					smallest = roll;
				if (secondsmall.compareTo(roll) < 0)
					secondsmall = roll;
			}
			
			
			for (T roll : list)
			{
				if (smallest.compareTo(roll) < 0 && secondsmall.compareTo(roll) > 0)
					secondsmall = roll;
			}
			
			return secondsmall;
		}
		
		public static void main(String[]args) {
			List<Integer> list = Arrays.asList(2,6,4,8,4,3,9,6,4);
			List<Double> dolist = Arrays.asList(9.8, 5.9, 8.1, 7.2, 0.9, 6.9, 4.9, 6.6);
			List<String> strlist = Arrays.asList("Solape", "Daniel", "Joshua", "Timothy", "Moses", "Caleb");
			System.out.println(secondSmallest(list));
			System.out.println(secondSmallest(dolist));
			System.out.println(secondSmallest(strlist));
			
		}
}
