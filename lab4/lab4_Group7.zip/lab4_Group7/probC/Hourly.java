package mpp_labs.lesson4.labs.probC;

class Hourly extends Employee {

	private int hourlyWage;
	private int hoursPerWeek;

	public Hourly() {
		this.hourlyWage = 10;
		this.hoursPerWeek = 50;
	}

	@Override
	double calcGrossPay(int month, int year) {

		return hourlyWage * hoursPerWeek;
	}

	public String print() {
		return "Hourly [hourlyWage=" + hourlyWage + ", hoursPerWeek=" + hoursPerWeek + "]";
	}

}
