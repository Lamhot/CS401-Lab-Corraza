package mpp_labs.lesson4.labs.probC;

abstract class Employee {

	int empId;
	
	abstract double calcGrossPay(int month, int year);
	
	public Paycheck calcCompensation(int month, int year){
		
		double grossPay = calcGrossPay(month, year);
		Paycheck payCheck = new Paycheck(grossPay);
		
		return payCheck;
	}


	public String print(){
		return "Employee [empId=" + empId + "]";
	}
}
