package mpp_labs.lesson4.labs.probC;



public class Driver {

	public static void main(String[] args){
		
		int month = 5;
		int year = 2019;
		
		HRDepartment hr = new HRDepartment();
		hr.printSalary(year, month);
	}
}
