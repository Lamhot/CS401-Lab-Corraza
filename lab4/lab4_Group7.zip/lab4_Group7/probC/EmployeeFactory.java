package mpp_labs.lesson4.labs.probC;

public class EmployeeFactory {

	public Employee createHourly(){
		return new Hourly();
	}
	
	public Employee createSalaried(){
		return new Salaried();
	}
	
	public Employee createCommissioned(){
		Commissioned commissioned = new Commissioned();
		commissioned.addOrder(new Order(1, "2019-2", 5000));
		commissioned.addOrder(new Order(1, "2019-5", 6000));
		commissioned.addOrder(new Order(1, "2019-6", 7000));
		return commissioned;
	}
}
