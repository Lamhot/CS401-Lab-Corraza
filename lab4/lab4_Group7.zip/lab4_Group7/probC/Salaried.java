package mpp_labs.lesson4.labs.probC;

class Salaried extends Employee{

	private int salary;
	
	public Salaried(){
		this.salary = 500;
	}
	
	@Override
	double calcGrossPay(int month, int year) {
		return salary;
	}

	public String print() {
		return "Salaried [salary=" + salary + "]";
	}

	
}
