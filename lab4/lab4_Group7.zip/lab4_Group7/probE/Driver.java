package mpp_labs.lesson4.labs.probE;

import java.util.ArrayList;
import java.util.List;

public class Driver {

	public static void main(String[] args) {

		Account accLamhot = new CheckingAccount(5000, 2, "Lamhot");
		Account accJordan = new SavingsAccount(5000, 0.5, "Jordan");
		List<Account> accounts = new ArrayList<>();
		accounts.add(accLamhot);
		accounts.add(accJordan);
		Employee c = new Employee("Lamhot");
		Employee customer1 = new Employee("Lamhot");
		Employee customer2 = new Employee("Lamhot");
		Employee customer3 = new Employee("Lamhot");
		c.addAccount(accLamhot);
		c.addAccount(accJordan);
		customer1.addAccount(accLamhot);
		customer1.addAccount(accJordan);
		customer2.addAccount(accLamhot);
		customer2.addAccount(accJordan);
		customer3.addAccount(accLamhot);
		customer3.addAccount(accJordan);

		List<Employee> list = new ArrayList<>();
		list.add(c);
		list.add(customer1);
		list.add(customer2);
		list.add(customer3);

		double sum = Admin.computeUpdatedBalanceSum(list);//static
		System.out.println(sum);

	}
}
