package mpp_labs.lesson4.labs.probE;

public abstract class Account {
	abstract String getAcountID();
	abstract double getBalance();
	abstract double getUpdateBalance();
	

}
