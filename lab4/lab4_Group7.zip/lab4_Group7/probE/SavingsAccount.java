package mpp_labs.lesson4.labs.probE;

public class SavingsAccount extends Account{
	

	private double balance;
	private double interestRate;
	private String accountID;
	
	
	public SavingsAccount(double balance, double interestRate, String acctId) {
		super();
		this.balance = balance;
		this.interestRate = interestRate;
		this.accountID = acctId;
	}


	@Override
	String getAcountID() {
		return accountID;
	}
	
	
	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public String getAcctId() {
		return accountID;
	}

	public void setAcctId(String acctId) {
		this.accountID = acctId;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	double getBalance() {
		return balance;
	}
	@Override
	double getUpdateBalance() {
		return balance + (interestRate * balance);
	}

}
