package lesson8.labs.prob1a.i;

public class RunableSample {
	public static void main(String[] args) {
		loopProducts(4, 10);
	}

	public static void loopProducts(int s, int t) {
		Runnable r = () -> {
		
			int[][] products = new int[s][t];
			for (int i = 0; i < s; i++) {
				for (int j = i + 1; j < t; j++) {
					products[i][j] = i * j;
				}
			}
		};
		new Thread(r).start();
	}
}
