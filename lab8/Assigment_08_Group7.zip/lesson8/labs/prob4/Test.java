package lesson8.labs.prob4;

import java.util.ArrayList;
import java.util.List;

public class Test {
	public static void main(String[] args){
		List<String> words=new ArrayList<String>();
		words.add("cccc");
		words.add("bskla");
		words.add("emd");
		words.add("ssjs");
		words.add("aasd");
		words.add("sdsd");
		words.add("lsshe");
		words.add("ab");
		words.add("bsd");
				
		Test countWords=new Test();
		System.out.println(countWords.countWords(words,'c','d',4));
	}
	public int countWords(List<String> words, char c, char d, int len){
		long count=words.stream()
		     .filter(s->s.length()==len)
		     .filter(s->s.contains(String.valueOf(c)))
		     .filter(s->!s.contains(String.valueOf(d)))
		     .count();	     
		return (int)count;
	}

}