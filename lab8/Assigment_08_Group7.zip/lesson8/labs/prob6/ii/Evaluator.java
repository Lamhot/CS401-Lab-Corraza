package lesson8.labs.prob6.ii;

import java.util.function.Function;

class eveluator{
	void evaluator(){
		Function<String, String> toUpper2 = (String e) -> e.toUpperCase()	;
		System.out.println(toUpper2.apply("hello"));
	}
}