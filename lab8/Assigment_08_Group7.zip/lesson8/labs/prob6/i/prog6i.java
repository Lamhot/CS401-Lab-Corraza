package lesson8.labs.prob6.i;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;
import java.util.function.Function;

public class prog6i {

	public static void main(String[] args) {

		// A. (Employee e) -> e.getName()
		Employee emp = new Employee("Joe", 100000);
		Function<Employee, String> getNameFunctionRM = Employee::getName;
		Function<Employee, String> getNameFunction = (Employee e) -> e.getName();

		System.out.println(getNameFunction.apply(emp));
		System.out.println(getNameFunctionRM.apply(emp));

		// B. (Employee e,String s) -> e.setName(s)
		BiConsumer<Employee, String> setNameBiEmployee = Employee::setName;
		BiConsumer<Employee, String> setName2 = (Employee e, String s) -> e.setName(s);

		Employee name = new Employee();
		setNameBiEmployee.accept(name, "New York");
		System.out.println(getNameFunction.apply(name));

		// C. (String s1,String s2) -> s1.compareTo(s2)
		Comparator<Employee> byName = (Employee o1, Employee o2) -> o1.getName().compareTo(o2.getName());
		Comparator<String> value = (String s1, String s2) -> s1.compareTo(s2);
		BiFunction<String, String, Integer> compare = (String s1, String s2) -> s1.compareTo(s2);

		// D. (Integer x,Integer y) -> Math.pow(x,y)
		BiFunction<Integer, Integer, Double> f = (x, y) -> Math.pow(x, y);
		System.out.println(f.apply(2, 3));
		BiFunction<Integer, Integer, Double> f2 = Math::pow;
		System.out.println(f2.apply(4, 5));

		// E. (Apple a) -> a.getWeight()
		List<Apple> inventory = new ArrayList<>();
		inventory.addAll(Arrays.asList(new Apple(80, "green"), new Apple(155, "green"), new Apple(120, "red")));

		Function<Apple, Integer> getApple = (Apple a) -> a.getWeight();
		Apple inv = new Apple(5, "five");
		System.out.println(getApple.apply(inv));

		// F. (String x) -> Integer.parseInt(x);

		Function<String, Integer> convertString = (String x) -> Integer.parseInt(x);
		System.out.println(convertString.apply("6"));

		// G. EmployeeNameComparator comp = new EmployeeNameComparator();
		// (Employee e1, Employee e2) -> comp.compare(e1,e2)

		EmployeeNameComparator comp = new EmployeeNameComparator();
		BiFunction<Employee, Employee, Integer> res = (Employee e1, Employee e2) -> comp.compare(e1, e2);

	}

}
