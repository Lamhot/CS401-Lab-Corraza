package lesson8.labs.prob1b;
import java.util.function.Supplier;

public class RandomInnerClass {
	
	public class SupplierImplementation implements Supplier<Double>{
		@Override
		public Double get() {
			return Math.random();
		}
	}
	
	public static void main(String[] args) {
		RandomInnerClass ir = new RandomInnerClass();
		SupplierImplementation object = ir.new SupplierImplementation();
		System.out.println(object.get());
	}

}