package lesson8.labs.prob1b;

import java.util.function.Supplier;

public class Test {
	public static void main(String[] args) {
		
		//using lambda
		Supplier<Double> randomLamda = () -> {
			return Math.random();
		};
		System.out.println(randomLamda.get());

		//Using method reference
		Supplier<Double> randomMR = Math::random;
		System.out.println(randomMR.get());

	}
}